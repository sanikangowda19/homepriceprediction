from flask import Flask, request, jsonify
import housepricepred  # Assuming housepricepred.py contains your prediction logic

app = Flask(__name__)

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    area = data['area']
    bhk = data['bhk']
    bathrooms = data['bathrooms']
    location = data['location']

    # Call the prediction function from housepricepred.py
    estimated_price = housepricepred.predict_price(area, bhk, bathrooms, location)
    
    return jsonify({'estimated_price': estimated_price})

if __name__ == "__main__":
    app.run(debug=True)
