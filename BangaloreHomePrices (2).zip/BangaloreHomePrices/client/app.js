let priceCalculated = false;

function onClickedEstimatePrice() {
  if (priceCalculated) {
    return;
  }

  var area = document.getElementById("uiSqft").value;
  var bhk = document.querySelector('input[name="uiBHK"]:checked').value;
  var bathrooms = document.querySelector('input[name="uiBathrooms"]:checked').value;
  var location = document.getElementById("uiLocations").value;

  // Check if area is not greater than 10000
  if (area > 10000) {
    alert("Area should not exceed 10,000 square feet.");
    return;
  }

  var estimatedPrice = calculateEstimatedPrice(area, bhk, bathrooms, location);

  if (estimatedPrice === "Please select a location") {
    document.getElementById("EstimatedPrice").innerHTML = "<h2>" + estimatedPrice + "</h2>";
  } else {
    document.getElementById("EstimatedPrice").innerHTML = "<h2>Estimated Price:</h2><div>" + formatPrice(estimatedPrice) + " rupees</div>";
  }

  document.getElementsByClassName("submit")[0].disabled = true;

  priceCalculated = true;
}

function calculateEstimatedPrice(area, bhk, bathrooms, location) {
  if (!location) {
    return "Please select a location";
  }

  let minPrice, maxPrice;

  // Set price ranges based on location
  switch (location) {
    case "Sadashiva Nagar":
      minPrice = 19900000;
      maxPrice = 21000000;
      break;
    case "Indira Nagar":
      minPrice = 13000000;
      maxPrice = 16000000;
      break;
    case "Sarjapur":
      minPrice = 11000000;
      maxPrice = 14000000;
      break;
    case "Rajaji Nagar":
      minPrice = 10000000;
      maxPrice = 13000000;
      break;
    case "Whitefield":
      minPrice = 9000000;
      maxPrice = 12000000;
      break;
    case "Kengeri":
      minPrice = 8000000;
      maxPrice = 11000000;
      break;
    case "Electronic City":
      minPrice = 7000000;
      maxPrice = 10000000;
      break;
    case "Yelahanka":
      minPrice = 6000000;
      maxPrice = 9000000;
      break;
    case "Uttarahalli":
      minPrice = 5500000;
      maxPrice = 8500000;
      break;
    case "Devanahalli":
      minPrice = 5000000;
      maxPrice = 8000000;
      break;
    default:
      // Set a default price range if location is not specified
      minPrice = 4500000;
      maxPrice = 20000000;
  }

  return Math.floor(Math.random() * (maxPrice - minPrice + 1)) + minPrice;
}

function formatPrice(price) {
  if (price >= 10000000) {
    var crores = Math.floor(price / 10000000);
    var lakhs = Math.floor((price % 10000000) / 100000);
    if (lakhs > 0) {
      return crores + " crore " + lakhs + " lakh";
    } else {
      return crores + " crore";
    }
  } else {
    var lakhs = Math.floor(price / 100000);
    return lakhs + " lakh";
  }
}
